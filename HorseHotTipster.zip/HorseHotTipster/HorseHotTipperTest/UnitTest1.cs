﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HorseHotTipperTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void HighestBetWonRaceCourse()
        {
            HighestBetWonRaceCourse hBetWonRaceCourse= new HorseHotTipster

        }
    }
}
