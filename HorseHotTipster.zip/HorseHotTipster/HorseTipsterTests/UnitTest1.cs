﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HorseHotTipster;

namespace HorseTipsterTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int i = Program.TestMethod();
            Assert.AreEqual(7, i);
        }

        [TestMethod]
        public void betsYearsTotalWonAndLost()
        {
            HorseBet hrBet = new HorseBet("Punchestown", new DateTime(2017,02,27), 20.30m, false);
            Assert.IsTrue(true);
        }
        [TestMethod]
        public void betsYearsTotalLost()
        {
            HorseBet hrBet = new HorseBet("Punchestown", new DateTime(2017, 02, 27), 20.30m, false);
            Assert.IsTrue(true);
        }
        [TestMethod]
        public void mostPopularRaceCourse()
        {
            HorseBet hrBet = new HorseBet("Punchestown", new DateTime(2017, 02, 27), 20.30m, false);
            Assert.IsTrue(true);
        }
        [TestMethod]
        public void mostBetsInDate()
        {
            //Arrange
            HorseBet betDate1 = new HorseBet("Bangor", new DateTime(2016, 01, 23), 10.00m, false);
            HorseBet betDate2 = new HorseBet("Puchestown", new DateTime(2016, 12, 22), 11.50m, true);
            //Act
            HorseBet horse = betDate1;
           // HorseBet horse1 = betDate2;
            //Assert
            Assert.AreNotEqual(betDate1.RaceDate, betDate2.RaceDate);
            Assert.AreNotEqual(betDate2.RaceCourse, betDate1.RaceDate);
        }
    }
}
