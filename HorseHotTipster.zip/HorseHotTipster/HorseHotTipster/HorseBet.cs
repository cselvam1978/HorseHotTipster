﻿using System;
using System.Text.RegularExpressions;
using System.Collections;
namespace HorseHotTipster
{
    [Serializable]public class HorseBet
    {
        public string RaceCourse { get; set; }
        public DateTime RaceDate { get; set; }
        public decimal Amount { get; set; }
        public bool RaceResult { get; set; }

        public HorseBet(string raceCourse, DateTime raceDate, decimal amount, bool result)
        {
            RaceCourse = raceCourse;
            RaceDate = raceDate;
            Amount = amount;
            RaceResult = result;

        }


        //Race Course Regex format & null message
        public void ValidRaceCourse(string raceCourse)
        {
            if (!Regex.IsMatch(raceCourse, @"^[A-Za-z]+$"))
            {
                throw new FormatException("Race course name should be in Upper/Lower case only!");
            }
            if (raceCourse == null)
            {
                throw new ArgumentNullException("Race Course name required");
            }
        }

        //Race date regEx date format & null message.
        //public void ValidRaceDate(DateTime raceDate)
        //{
        //    if (!Regex.IsMatch(raceDate, @"\d{4}[- /.]([1-9]|0[1-9]|1[012])[- /.]([1-9]|0[1-9]|[12][0-9]|3[01])"))
        //    {
        //        throw new FormatException("Invalid! date format:YYYY,MM,DD");
        //    }
        //    if (raceDate == null)
        //    {
        //        throw new ArgumentNullException("Enter valid RaceDate");
        //    }

        //}

    }
}
