﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace HorseHotTipster
{
    delegate void PrintResult(List<HorseBet> bets);
    public class Program
    {
        //File Path directories
        public static readonly string FILE_PATH = $@"C:\Users\me\Desktop\Selvam\10362832_SelvamChinnasamy_AdvProg\HorseHotTipster\HorseHotTipster\horsebets.bin";


        //List
        static List<HorseBet> hBets = new List<HorseBet>
                {
                     new HorseBet ( "Aintree", new DateTime(2017,05,12),11.58m,true ),
                     new HorseBet ( "Punchestown", new DateTime( 2016, 12, 22),  122.52m,  true ),
                     new HorseBet ( "Sandown", new DateTime(2016, 12, 22), 20.00m,  false),
                     new HorseBet ( "Ayr", new DateTime( 2017, 05, 12), 11.58m,false ),
                     new HorseBet ( "Fairyhouse", new DateTime(2017, 05, 12),11.58m,  true ),
                     new HorseBet ("Ayr",new DateTime(2016, 11, 03),12.05m, true ),
                     new HorseBet ( "Doncaster", new DateTime(2017, 12, 02),10.00m, false ),
                     new HorseBet ("Towcaster", new DateTime( 2016, 03, 12),  50.00m, false ),
                     new HorseBet ( "Goodwood", new DateTime(2017, 10, 07), 525.74m,  true ),
                     new HorseBet ("Kelso", new DateTime( 2016, 09, 13),  43.21m,  true ),
                     new HorseBet ("Punchestown", new DateTime(2017, 07, 05), 35.00m, false ),
                     new HorseBet ("Ascot", new DateTime(2016, 02, 04),  23.65m, true ),
                     new HorseBet ( "Kelso", new DateTime(2017, 08, 02), 30.00m,  false ),
                     new HorseBet ("Towcaster", new DateTime(2017, 05, 01),  104.33m, true ),
                     new HorseBet ("Ascot", new DateTime(2017, 06, 23), 300.00m,  false  ),
                     new HorseBet ("Ascot", new DateTime(2017, 06, 23),  34.12m, true  ),
                     new HorseBet ("Goodwood", new DateTime(2016, 10, 05),  525.74m, true  ),
                     new HorseBet ("Dundalk", new DateTime(2016, 11, 09),  20.00m,  false ),
                     new HorseBet ("Haydock",new DateTime(2016,11,12),87.00M, true),
                     new HorseBet ("Perth",new DateTime(2017,01,20),15.00m,false),
                     new HorseBet ( "York", new DateTime(2017, 11, 11), 101.25m,  true  ),
                     new HorseBet ("Punchestown", new DateTime(2016, 12, 22),  11.50m,  true ),
                     new HorseBet ("Chester", new DateTime(2016, 08, 14), 10.00m,false  ),
                     new HorseBet ("Kelso", new DateTime(2016, 09, 18),  10.00m,  false  ),
                     new HorseBet ( "Kilbeggan", new DateTime(2017, 03, 03),  20.00m,  false  ),
                     new HorseBet ( "Fairyhouse", new DateTime(2017, 03, 11),55.50m,true ),
                     new HorseBet ("Punchestown",new DateTime(2016, 11, 15),10.00m,false),
                     new HorseBet ("Towcester",new DateTime(2016, 05, 08),16.55m,true),
                     new HorseBet ( "Punchestown", new DateTime(2016, 05, 23), 13.71m, true  ),            
                     new HorseBet ( "Cork", new DateTime(2016, 11, 30), 20.00m,  false),             
                     new HorseBet ( "Punchestown", new DateTime(2016, 04, 25), 13.45m, true ),           
                     new HorseBet("Bangor",new DateTime(2016, 01, 23),10.00m,false),
                     new HorseBet("Sandown",new DateTime(2017, 08, 07),25.00m,false)

                 };

        
        static void Main(string[] args)
        {
            //Declaring variables
           
            bool exit = false;
           
            int menuOption;

            //Menu Option
            while (exit == false)
            {

                Console.WriteLine("1. Enter a bet: ");
                Console.WriteLine("2. Write to binary file: ");
                Console.WriteLine("3. Read from binary file: ");
                Console.WriteLine("4. Years total won and total lost: ");
                Console.WriteLine("5. most popular racecourse: ");
                Console.WriteLine("6. Bets in date order: ");
                Console.WriteLine("7. Highest amont won & lost: ");
                Console.WriteLine("8. How successful: ");
                Console.WriteLine("9. Quit the program");
                

                menuOption = int.Parse(Console.ReadLine());

                switch (menuOption)
                {

                    case 1:
                        enterABet();
                        Console.WriteLine("#######################");
                        break;
                    case 2:
                        writeBinaryFile();
                        Console.WriteLine("#######################");
                        break;
                    case 3:
                        readBinaryFile();
                        Console.WriteLine("#######################");
                        break;
                    case 4:
                        yearsTotalWonAndLost();
                        Console.WriteLine("#######################");
                        break;
                    case 5:
                        mostPopularRaceCourse();
                        Console.WriteLine("#######################");
                        break;
                    case 6:
                        betsInDateOrder();
                        Console.WriteLine("#######################");
                        break;
                    case 7:
                        highestAmountWonAndLost(hBets);
                        Console.WriteLine("#######################");
                        break;
                    case 8:
                        winningRatio(hBets);
                        Console.WriteLine("#######################");
                        break;
                    case 9:
                        if (menuOption==9)
                        {
                            exit = true;
                        }
                        break;
                }
            }
        }

        public static int TestMethod()
        {
           
            int j = 7;
            return j;
        }

        //Enter bet menu
        public static void enterABet()
        {
            string raceCourse;
            DateTime raceDate;
            decimal amount;
            bool result = false;

            Console.Write("Enter race course: ");
            raceCourse = Console.ReadLine();

            Console.Write("Enter race date(YYYY,MM,DD): ");
            raceDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter amount: ");
            amount = decimal.Parse(Console.ReadLine());

            Console.Write("Enter the state of the bet(true = won, false = Lost): ");
            result = bool.Parse(Console.ReadLine());

            HorseBet h = new HorseBet(raceCourse,raceDate,amount,result);
            hBets.Add(h);

        }
        //write a binary file
        public static void writeBinaryFile()
        {
        
            using (Stream filestream = File.Open(FILE_PATH, FileMode.OpenOrCreate))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(filestream, hBets);
                filestream.Close();
            }
           
        }
        //Reading binary file
        public static void readBinaryFile()
        {
            List<HorseBet> serBets = null;
            using (Stream filestream = File.Open(FILE_PATH, FileMode.Open))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                serBets = (List<HorseBet>)binaryFormatter.Deserialize(filestream);
                filestream.Close();

                foreach (HorseBet item in serBets)
                {
                    Console.Write("{0}\t\t {1}\t\t {2}\t\t {3}",item.RaceCourse,"\t\t",item.RaceDate," \t\t",item.Amount," \t\t", item.RaceResult );
                }

            }
        }
        //Report of Total won and Lost in year...
        public static void yearsTotalWonAndLost()
        {
            var yearTotal = from horseBets in hBets
                            orderby horseBets.RaceDate
                            let hb = new
                            {
                                Year = horseBets.RaceDate.ToString(),
                            }
                            group horseBets by hb into yt
                            select new
                            {
                                Year=yt.Key.Year,
                                Loss=yt.Where(m=>m.RaceResult==false).Sum(m=>m.Amount), 
                                Won =yt.Where(m=>m.RaceResult==true).Sum(m=>m.Amount)
                            };
            Console.WriteLine("\tYear\t\t\tTotal Loss\t\tTotal Won");
            foreach (var item in yearTotal)
            {
                Console.WriteLine("{0}\t\t{1}\t\t{2}",item.Year,item.Loss,item.Won);                
            }
        }
        //most popular race course of the year
        public static void mostPopularRaceCourse()
        {
            var raceCourse = hBets.GroupBy(m => m.RaceCourse).OrderByDescending(m => m.Count())
                .First().Key;
           
                Console.Write($"Most Horse bets were placed at {raceCourse.ToString()}"+Environment.NewLine);
            
        }
        //Shows bet in date order
        public static void betsInDateOrder()
        {
            var betDates = hBets.OrderBy(m => m.RaceDate);
            using (Stream fs = new FileStream($@"{FILE_PATH}", FileMode.OpenOrCreate))
            {
                foreach (var date in betDates)
                {
                    Console.Write($"Race Course: {date.RaceCourse}" + " \t\t "
                                + $"Race Date: {date.RaceDate}" + " \t\t "
                                + $"Amount : {date.Amount}" + " \t "
                                + $"Race Result: {date.RaceResult}" + Environment.NewLine
                        );
                }
            }
        }

        //Highest win and Lost
        public static void highestAmountWonAndLost(List<HorseBet> hBets)
        {
            //Highest winning
            var highestWinAmount = hBets.Where(m => m.RaceResult == true).Max(m=>m.Amount);
            var highestWins = hBets.Where(m => m.Amount == highestWinAmount).First();

            //Highest lost
            var highestLostAmount = hBets.Where(m => m.RaceResult == false).Max(m => m.Amount);
            var highestLost = hBets.Where(m => m.Amount == highestLostAmount).First();

            Console.WriteLine("Highest Won\t\t\t\tHighest Lost");
            using (Stream fStream = new FileStream($@"{FILE_PATH}", FileMode.OpenOrCreate))
            {
                Console.WriteLine($"Highest Winning Amount  is:  {highestWins.Amount}"+"  "+
                                  $"Highest Lost Amount is: {highestLost.Amount}"
                    );
            }
        }
        //Winning Ratio
        public static void winningRatio(List<HorseBet> hBets)
        {
            
            var horseRaces = hBets.Count();
            var wins = hBets.Where(m => m.RaceResult == true).Count();
            string winningRatio = wins.ToString() + "/" + horseRaces.ToString()+Environment.NewLine;
            using (Stream fStream=new FileStream($@"{FILE_PATH}",FileMode.OpenOrCreate))
            {
                Console.WriteLine($"Winning Ratio is {winningRatio}"+Environment.NewLine);
            }
        }
    }
}
