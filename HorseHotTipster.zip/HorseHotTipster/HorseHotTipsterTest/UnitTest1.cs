﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HorseHotTipster;

namespace HorseHotTipsterTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void HighestBetWonRaceCourse()
        //{
        //    //List<HorseBet>hBet=new List<HorseBet>()
        //    HorseBet horseBet = new HorseBet("Punchestown", 2017, 09, 13, 250.00, true);
        //    HighestBet hBet = new HighestBet(horseBet);
            
        }
    }
}
